import 'package:flutter/material.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'screens/create_pokemon_screen.dart';
import 'screens/my_creations_screen.dart';

void main() => runApp(PokelogApp());

class PokelogApp extends StatelessWidget {
  final List<Map<String, String>> customPokemons = [];
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pokelog',
      theme: ThemeData(primarySwatch: Colors.blue),
      initialRoute: '/',
      routes: {
        '/': (context) => LoginScreen(),
        '/home': (context) => HomeScreen(),
        '/create': (context) => CreatePokemonScreen(),
        '/creations': (context) =>
            MyCreationsScreen(customPokemons: customPokemons),
      },
    );
  }
}
