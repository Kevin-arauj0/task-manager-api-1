import 'package:flutter/material.dart';
import '../services/api_service.dart';

class HomeScreen extends StatelessWidget {
  final ApiService apiService = ApiService();
  final TextEditingController controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Pokelog")),
      body: Column(
        children: [
          TextField(
            controller: controller,
            decoration: InputDecoration(labelText: "Buscar Pokémon"),
          ),
          ElevatedButton(
            onPressed: () async {
              final pokemon = await apiService.fetchPokemon(controller.text);
              // Exibir resultado (implementar lógica)
            },
            child: Text("Pesquisar"),
          ),
        ],
      ),
    );
  }
}
