import 'package:flutter/material.dart';

class CreatePokemonScreen extends StatefulWidget {
  @override
  _CreatePokemonScreenState createState() => _CreatePokemonScreenState();
}

class _CreatePokemonScreenState extends State<CreatePokemonScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController typeController = TextEditingController();
  final TextEditingController abilityController = TextEditingController();

  List<Map<String, String>> customPokemons = [];

  void savePokemon() {
    final String name = nameController.text.trim();
    final String type = typeController.text.trim();
    final String ability = abilityController.text.trim();

    if (name.isEmpty || type.isEmpty || ability.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Preencha todos os campos!')),
      );
      return;
    }

    setState(() {
      customPokemons.add({
        'name': name,
        'type': type,
        'ability': ability,
      });
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Pokémon $name criado com sucesso!')),
    );

    nameController.clear();
    typeController.clear();
    abilityController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Criar Pokémon')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: nameController,
              decoration: InputDecoration(labelText: 'Nome do Pokémon'),
            ),
            TextField(
              controller: typeController,
              decoration: InputDecoration(labelText: 'Tipo (ex: Fogo, Água)'),
            ),
            TextField(
              controller: abilityController,
              decoration: InputDecoration(labelText: 'Habilidade'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: savePokemon,
              child: Text('Salvar Pokémon'),
            ),
          ],
        ),
      ),
    );
  }
}
