import 'package:flutter/material.dart';

class MyCreationsScreen extends StatelessWidget {
  final List<Map<String, String>> customPokemons;

  MyCreationsScreen({required this.customPokemons});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Minhas Criações')),
      body: customPokemons.isEmpty
          ? Center(child: Text('Nenhum Pokémon criado ainda!'))
          : ListView.builder(
              itemCount: customPokemons.length,
              itemBuilder: (context, index) {
                final pokemon = customPokemons[index];
                return ListTile(
                  title: Text(pokemon['name'] ?? 'Sem Nome'),
                  subtitle: Text(
                    'Tipo: ${pokemon['type']} | Habilidade: ${pokemon['ability']}',
                  ),
                  leading: CircleAvatar(
                    child: Text(pokemon['name']![0].toUpperCase()),
                  ),
                );
              },
            ),
    );
  }
}
