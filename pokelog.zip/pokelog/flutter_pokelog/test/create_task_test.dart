import 'package:http/http.dart' as http;
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Criar uma nova tarefa deve retornar 201', () async {
    final response = await http.post(
      Uri.parse('https://sua-api-endpoint.com/tasks'),
      headers: {'Content-Type': 'application/json'},
      body: '{"title": "Nova Tarefa", "description": "Descrição da tarefa"}',
    );
    expect(response.statusCode, 201);
  });
}
