import 'package:http/http.dart' as http;
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Listar tarefas deve retornar uma lista de tarefas', () async {
    final response = await http.get(Uri.parse('https://sua-api-endpoint.com/tasks'));
    expect(response.statusCode, 200);
    expect(response.body, isNotEmpty);
  });
}
